﻿using WebAppFizzBuzz.Models;
using System.Collections.Generic;
using WebAppFizzBuzz.Utility;

namespace WebAppFizzBuzz.Services
{
    public class FizzBuzzService : IFizzBuzzService
    {
        #region CheckIntvalue
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>

        public FizzBuzzResult PerformFizzBuzzService(object value)
        {
            FizzBuzzResult result = new FizzBuzzResult { Value = value };

            Calculation objCal = new Calculation();
            if (int.TryParse(value.ToString(), out int result1))
            {
                return objCal.PerformCalculation(result1);
            }
            else
            {
                result.Result = "Invalid Item";
                return result;
            }
        }
        #endregion

        #region Perform Calculation
        /// <summary>
        /// Cobver all test conditions
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>

        public FizzBuzzResult ProcessIntValue(int value)
        {
            FizzBuzzResult result = new FizzBuzzResult { Value = value };

            var isDividedBy3 = (value % 3) == 0;
            var isDividedBy5 = (value % 5) == 0;

            if (isDividedBy3 && isDividedBy5)
            {
                result.Result += "FizzBuzz";

            }
            else if (isDividedBy3)
            {
                result.Result += "Fizz";
            }
            else if (isDividedBy5)
            {
                result.Result += "Buzz";
            }
            else
            {
                if (!isDividedBy3)
                {
                    result.Result += "Divided " + value + " by 3.";
                }

                if (!isDividedBy5)
                {
                    result.Result += " Divided " + value + " by 5.";
                }
            }

            return result;
        }
        #endregion
    }

}
