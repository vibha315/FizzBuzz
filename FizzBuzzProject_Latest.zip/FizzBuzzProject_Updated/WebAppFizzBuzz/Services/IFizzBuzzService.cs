﻿using WebAppFizzBuzz.Models;

namespace WebAppFizzBuzz.Services
{
    public interface IFizzBuzzService
    {
        FizzBuzzResult PerformFizzBuzzService(object value);
    }
}
