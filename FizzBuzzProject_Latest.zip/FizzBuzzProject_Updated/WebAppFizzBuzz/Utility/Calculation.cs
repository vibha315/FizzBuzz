﻿using WebAppFizzBuzz.Models;

namespace WebAppFizzBuzz.Utility
{
    public class Calculation
    {
        #region Perform Calculation
        /// <summary>
        /// cover all test conditions
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>

        public FizzBuzzResult PerformCalculation(int value)
        {
            FizzBuzzResult result = new FizzBuzzResult();

            var isDividedBy3 = (value % 3) == 0;
            var isDividedBy5 = (value % 5) == 0;

            if (isDividedBy3 && isDividedBy5)
            {
                result.Result += "FizzBuzz";

            }
            else if (isDividedBy3)
            {
                result.Result += "Fizz";
            }
            else if (isDividedBy5)
            {
                result.Result += "Buzz";
            }
            else
            {
                if (!isDividedBy3)
                {
                    result.Result += "Divided " + value + " by 3.";
                }

                if (!isDividedBy5)
                {
                    result.Result += " Divided " + value + " by 5.";
                }
            }

            return result;
        }
        #endregion
    }
}
