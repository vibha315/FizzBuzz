using WebAppFizzBuzz.Controllers;
using NUnit.Framework;
using WebAppFizzBuzz.Models;
using Newtonsoft.Json.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using WebAppFizzBuzz.Services;

namespace FizzBuzzUnitTestProject
{
    [TestFixture]
    public class FizzBuzzUnitTests
    {
        private FizzBuzzService _fizzBuzzService { get; set; }

        [SetUp]
        public void Setup()
        {
            _fizzBuzzService = new FizzBuzzService();

        }

        
        [Test]
        public void TestProcessArray_ShouldReturnFizzForMultiplesOfArrayValues()
        {
            object[] Arrayvalues = { 3,5,15,"A",23,1};
            for (int i = 0; i < Arrayvalues.Length; i++)
            {
                var result = _fizzBuzzService.PerformFizzBuzzService(Arrayvalues[i]);
                if (i == 0)
                {
                    Assert.AreEqual("Fizz", result.Result);
                }
                if(i == 1)
                {
                    Assert.AreEqual("Buzz", result.Result);
                }
                if (i == 2)
                {
                    Assert.AreEqual("FizzBuzz", result.Result);
                }
                if (i == 3)
                {
                    Assert.AreEqual("Invalid Item", result.Result);
                }
                if (i == 4)
                {
                    Assert.AreEqual("Divided " + Arrayvalues[i] + " by 3. Divided " + Arrayvalues[i] + " by 5.", result.Result);
                   
                }
              

            }

        }

    }
}