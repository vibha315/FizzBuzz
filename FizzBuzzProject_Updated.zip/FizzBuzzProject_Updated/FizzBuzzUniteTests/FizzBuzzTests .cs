﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FizzBuzzUniteTests.Services
    using WebAppFizzBuzz.Services


using System;
using System.Collections.Generic;

namespace FizzBuzzUniteTests
{

    [TestClass]
    public class FizzBuzzProcessorTests
    {
        [TestMethod]
        public void TestFizzBuzzProcessor()
        {
           
            [TestMethod]
            public void TestProcessArray_ShouldReturnFizzForMultiplesOf3()
            {
                // Arrange
                var controller = new FizzBuzzController();
                var values = new object[] { 3, 6, 9, 12 };

                // Act
                var result = controller.PerformFizzBuzz(values) as OkObjectResult;
                var results = result?.Value as List<string>;

                // Assert
                CollectionAssert.AreEqual(new[] { "Fizz", "Fizz", "Fizz", "Fizz" }, results);
            }


            [TestMethod]
            public void TestProcessArray_ShouldReturnBuzzForMultiplesOf5()
            {
                // Arrange
                var controller = new FizzBuzzController();
                var values = new object[] { 5, 10, 20, 25 };

                // Act
                var result = controller.PerformFizzBuzz(values) as OkObjectResult;
                var results = result?.Value as List<string>;

                // Assert
                CollectionAssert.AreEqual(new[] { "Buzz", "Buzz", "Buzz", "Buzz" }, results);
            }
            [TestMethod]
            public void ProcessArray_ShouldReturnFizzBuzzForMultiplesOf3And5()
            {
                // Arrange
                object[] values = { 15, 30, 45, 60 };

                var result = controller.PerformFizzBuzz(values) as OkObjectResult;
                var results = result?.Value as List<string>;
                // Assert
                CollectionAssert.AreEqual(new[] { "FizzBuzz", "FizzBuzz", "FizzBuzz", "FizzBuzz" }, results);
            }
            [TestMethod]
            public void ProcessArray_ShouldReturnOriginalValueForNonMultiples()
            {
                // Arrange
                object[] values = { 1  "two", "", "eight","A" };

                // Act

                var result = controller.PerformFizzBuzz(values) as OkObjectResult;
                var results = result?.Value as List<string>;

                // Assert
                CollectionAssert.AreEqual(new[] { "Divided 1 by 3. \n Divided 1 by 5 ", "Invalid Item", "Invalid Item", "Invalid Item" }, results);
            }

        }
    }
}
