﻿using Microsoft.AspNetCore.Mvc;
using WebAppFizzBuzz.Models;
using WebAppFizzBuzz.Services;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace WebAppFizzBuzz.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FizzBuzzController : ControllerBase
    {
        private readonly IFizzBuzzService _fizzBuzzService;

        public FizzBuzzController(IFizzBuzzService fizzBuzzService)
        {
            _fizzBuzzService = fizzBuzzService;
        }
        #region PerformFizzBuzz
        /// <summary>
        /// perform all calculation of testcase wise
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
      
        [HttpPost("PerformFizzBuzz")]
        public ActionResult<IEnumerable<FizzBuzzResult>> PerformFizzBuzz([FromBody] object[] userValues)
        {
            List<string> results = new List<string>();
            // object[] values = { 1,3,5, "", 15 ,"A",23 };

            foreach (var value in userValues)
            {
                Console.WriteLine(value);
                var result = _fizzBuzzService.PerformFizzBuzz(value);
                results.Add("Input " + result.Value+": " + result.Result);
            }
        


            return Ok(results);
        }
        #endregion
    }
}
