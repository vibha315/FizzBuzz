﻿using WebAppFizzBuzz.Models;

namespace WebAppFizzBuzz.Services
{
    public interface IFizzBuzzService
    {
        FizzBuzzResult PerformFizzBuzz(object value);
    }
}
