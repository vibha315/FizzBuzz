﻿namespace WebAppFizzBuzz.Models
{
    public class FizzBuzzResult
    {
        public object Value { get; set; }
        public string Result { get; set; }
    }
}